
public class VariousVariables {

    public static void main(String[] args) {
        // MODIFY THESE:

        int numberOfChicken = 3;
        double baconWeight = 5.5;
        String tractor = "None!";

        // DON'T MODIFY THESE:
        System.out.println("Chicken:");
        System.out.println(numberOfChicken);
        System.out.println("Bacon (kg):");
        System.out.println(baconWeight);
        System.out.println("Tractor:");
        System.out.println(tractor);
        System.out.println("");
        System.out.println("And finally, a summary:");
        System.out.println(numberOfChicken);
        System.out.println(baconWeight);
        System.out.println(tractor);
    }
}
