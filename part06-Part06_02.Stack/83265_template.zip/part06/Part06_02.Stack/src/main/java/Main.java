
public class Main {

    public static void main(String[] args) {

        // Try out your class here

    }
}
